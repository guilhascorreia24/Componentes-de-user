from django.apps import AppConfig


class LesConfig(AppConfig):
    name = 'les'

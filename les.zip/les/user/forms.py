from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()
    telefone=forms.CharField()
    username=forms.CharField()
    password1=forms.CharField()
    password2=forms.CharField()
    class Meta:
        model = User
        fields = ['username', 'email', 'telefone' ,'password1','password2']

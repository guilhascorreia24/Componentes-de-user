# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

# NOTIFICAÇAO HORA DE ENVIADA E RECEBIDA ????????????????????????????????????

class Administrador(models.Model):
    utilizador_idutilizador = models.OneToOneField('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'administrador'

    def __str__(self):
        return self.utilizador_idutilizador
    



class Atividade(models.Model):
    idatividade = models.AutoField(db_column='idAtividade', primary_key=True)  # Field name made lowercase.
    capacidade = models.IntegerField(blank=True, null=True)
    duracao = models.FloatField(blank=True, null=True)
    professor_universitario_utilizador_idutilizador = models.ForeignKey('ProfessorUniversitario', on_delete=models.CASCADE, db_column='Professor Universitario_Utilizador_idutilizador')  # Field name made lowercase. Field renamed to remove unsuitable characters.
    unidade_organica_iduo = models.ForeignKey('UnidadeOrganica', on_delete=models.CASCADE, db_column='unidade Organica_idUO')  # Field name made lowercase. Field renamed to remove unsuitable characters.
    departamento_iddepartamento = models.ForeignKey('Departamento', on_delete=models.CASCADE, db_column='Departamento_idDepartamento')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'atividade'
    
    def __str__(self):
        return self.idatividade


class AtividadeHasMaterial(models.Model):
    atividade_idatividade = models.OneToOneField(Atividade, on_delete=models.CASCADE, db_column='Atividade_idAtividade', primary_key=True)  # Field name made lowercase.
    material_idmaterial = models.ForeignKey('Material', on_delete=models.CASCADE, db_column='Material_idMaterial')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'atividade_has_material'
        unique_together = (('atividade_idatividade', 'material_idmaterial'),)
    
    def __str__(self):
        return self.atividade_idatividade


class Campus(models.Model):
    idcampus = models.AutoField(db_column='idCampus', primary_key=True)  # Field name made lowercase.
    nome = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus'
    
    def __str__(self):
        return self.idcampus


class Colaborador(models.Model):
    curso = models.CharField(max_length=45, blank=True, null=True)
    preferencia = models.CharField(max_length=45, blank=True, null=True)
    utilizador_idutilizador = models.OneToOneField('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    dia_aberto_ano = models.ForeignKey('DiaAberto', on_delete=models.CASCADE, db_column='Dia Aberto_ano')  # Field name made lowercase. Field renamed to remove unsuitable characters.

    class Meta:
        managed = False
        db_table = 'colaborador'
    
    def __str__(self):
        return self.utilizador_idutilizador


class ColaboradorHasHorario(models.Model):
    colaborador_utilizador_idutilizador = models.OneToOneField(Colaborador, on_delete=models.CASCADE, db_column='colaborador_Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    horario_horainicio = models.ForeignKey('Horario', on_delete=models.CASCADE, db_column='Horario_horainicio')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'colaborador_has_horario'
        unique_together = (('colaborador_utilizador_idutilizador', 'horario_horainicio'),)
    
    def __str__(self):
        return self.colaborador_utilizador_idutilizador


class ColaboradorHasUnidadeOrganica(models.Model):
    colaborador_utilizador_idutilizador = models.OneToOneField(Colaborador, on_delete=models.CASCADE, db_column='colaborador_Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    unidade_organica_iduo = models.ForeignKey('UnidadeOrganica', on_delete=models.CASCADE, db_column='unidade Organica_idUO')  # Field name made lowercase. Field renamed to remove unsuitable characters.

    class Meta:
        managed = False
        db_table = 'colaborador_has_unidade organica'
        unique_together = (('colaborador_utilizador_idutilizador', 'unidade_organica_iduo'),)
    
    def __str__(self):
        return self.colaborador_utilizador_idutilizador


class Coordenador(models.Model):
    utilizador_idutilizador = models.OneToOneField('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    unidade_organica_iduo = models.ForeignKey('UnidadeOrganica', on_delete=models.CASCADE, db_column='unidade Organica_idUO')  # Field name made lowercase. Field renamed to remove unsuitable characters.

    class Meta:
        managed = False
        db_table = 'coordenador'

    def __str__(self):
        return self.utilizador_idutilizador


class CoordenadorHasDepartamento(models.Model):
    coordenador_utilizador_idutilizador = models.OneToOneField(Coordenador, on_delete=models.CASCADE, db_column='Coordenador_Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    departamento_iddepartamento = models.ForeignKey('Departamento', on_delete=models.CASCADE, db_column='Departamento_idDepartamento')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'coordenador_has_departamento'
        unique_together = (('coordenador_utilizador_idutilizador', 'departamento_iddepartamento'),)

    def __str__(self):
        return self.coordenador_utilizador_idutilizador

class Departamento(models.Model):
    iddepartamento = models.AutoField(db_column='idDepartamento', primary_key=True)  # Field name made lowercase.
    nome = models.CharField(max_length=45)
    iduo = models.CharField(db_column='idUO', max_length=45)  # Field name made lowercase.
    unidade_organica_iduo = models.ForeignKey('UnidadeOrganica', on_delete=models.CASCADE, db_column='unidade Organica_idUO')  # Field name made lowercase. Field renamed to remove unsuitable characters.

    class Meta:
        managed = False
        db_table = 'departamento'
    
    def __str__(self):
        return self.iddepartamento

class DiaAberto(models.Model):
    ano = models.AutoField(primary_key=True)
    descricao = models.CharField(max_length=120, blank=True, null=True)
    datainscricao = models.DateField()
    emaildiaaberto = models.CharField(db_column='emailDiaAberto', max_length=120)  # Field name made lowercase.
    enderecopaginaweb = models.CharField(db_column='enderecoPaginaWeb', max_length=60)  # Field name made lowercase.
    datadiainscricaoatividadesinicio = models.DateField(db_column='dataDiainscricaoAtividadesInicio')  # Field name made lowercase.
    datadiaabertoinicio = models.DateField(db_column='dataDiaAbertoInicio')  # Field name made lowercase.
    datainscricaoatividadesfim = models.DateField(db_column='dataInscricaoAtividadesfim')  # Field name made lowercase.
    datadiaabertofim = models.DateField(db_column='dataDiaAbertofim')  # Field name made lowercase.
    datapropostaatividadeinicio = models.DateField(db_column='dataPropostaAtividadeInicio')  # Field name made lowercase.
    datapropostaatividadesfim = models.DateField(db_column='dataPropostaAtividadesFim')  # Field name made lowercase.
    utilizador_idutilizador = models.ForeignKey('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador')  # Field name made lowercase.
    administrador_utilizador_idutilizador = models.ForeignKey(Administrador, on_delete=models.CASCADE, db_column='Administrador_Utilizador_idutilizador')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'dia aberto'
    
    def __str__(self):
        return self.ano

class Escola(models.Model):
    idescola = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=45)
    local = models.CharField(max_length=45)
    telefone = models.CharField(max_length=45)
    email = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'escola'
    
    def __str__(self):
        return self.idescola


class Espaco(models.Model):
    idespaco = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=45)
    sessao_idsessao = models.ForeignKey('Sessao', on_delete=models.CASCADE, db_column='sessao_idsessao')

    class Meta:
        managed = False
        db_table = 'espaco'
    
    def __str__(self):
        return self.idespaco


class Horario(models.Model):
    horainicio = models.IntegerField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'horario'
    
    def __str__(self):
        return self.horainicio

class Idioma(models.Model):
    nome = models.CharField(primary_key=True, max_length=24)
    sigla = models.CharField(unique=True, max_length=45)
    administrador_utilizador_idutilizador = models.ForeignKey(Administrador, on_delete=models.CASCADE, db_column='Administrador_Utilizador_idutilizador')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'idioma'
    
    def __str__(self):
        return self.nome


class Inscricao(models.Model):
    idinscricao = models.AutoField(primary_key=True)
    ano = models.TextField(blank=True, null=True)  # This field type is a guess.
    local = models.CharField(max_length=45, blank=True, null=True)
    areacientifica = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'inscricao'

    def __str__(self):
        return self.idinscricao

class InscricaoColetiva(models.Model):
    nresponsaveis = models.IntegerField(blank=True, null=True)
    turma = models.CharField(max_length=1, blank=True, null=True)
    participante_utilizador_idutilizador = models.ForeignKey('Participante', on_delete=models.CASCADE, db_column='Participante_Utilizador_idutilizador')  # Field name made lowercase.
    escola_idescola = models.ForeignKey(Escola, on_delete=models.CASCADE, db_column='escola_idescola', blank=True, null=True)
    inscricao_idinscricao = models.OneToOneField(Inscricao, on_delete=models.CASCADE, db_column='inscricao_idinscricao', primary_key=True)

    class Meta:
        managed = False
        db_table = 'inscricao coletiva'
    
    def __str__(self):
        return self.inscricao_idinscricao


class InscricaoIndividual(models.Model):
    nracompanhades = models.IntegerField()
    participante_utilizador_idutilizador = models.ForeignKey('Participante', on_delete=models.CASCADE, db_column='Participante_Utilizador_idutilizador')  # Field name made lowercase.
    inscricao_idinscricao = models.OneToOneField(Inscricao, on_delete=models.CASCADE, db_column='inscricao_idinscricao', primary_key=True)

    class Meta:
        managed = False
        db_table = 'inscricao individual'
    
    def __str__(self):
        return self.inscricao_idinscricao


class Material(models.Model):
    idmaterial = models.IntegerField(db_column='idMaterial', primary_key=True)  # Field name made lowercase.
    descricao = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'material'

    def __str__(self):
        return self.idmaterial

class Menu(models.Model):
    idmenu = models.AutoField(db_column='idMenu', primary_key=True)  # Field name made lowercase.
    precoaluno = models.FloatField(db_column='precoAluno')  # Field name made lowercase.
    precoprofessor = models.FloatField(db_column='PrecoProfessor')  # Field name made lowercase.
    tipo = models.CharField(max_length=45)
    menu = models.CharField(max_length=45, blank=True, null=True)
    administrador_utilizador_idutilizador = models.ForeignKey(Administrador, on_delete=models.CASCADE, db_column='Administrador_Utilizador_idutilizador')  # Field name made lowercase.
    campus_idcampus = models.ForeignKey(Campus, on_delete=models.CASCADE, db_column='Campus_idCampus')  # Field name made lowercase.
    horario_idhorario = models.ForeignKey(Horario, on_delete=models.CASCADE, db_column='Horario_idhorario')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'menu'

    def __str__(self):
        return self.idmenu

class Notificacao(models.Model):
    id=models.AutoField(db_column='id', primary_key=True)
    descricao = models.CharField(max_length=45, blank=True, null=True)
    criadoem = models.CharField(max_length=45, blank=True, null=True)
    idutilizadorenvia = models.IntegerField()
    utilizadorrecebe = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'notificacao'

    def __str__(self):
        return self.id

class Participante(models.Model):
    utilizador_idutilizador = models.OneToOneField('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'participante'

    def __str__(self):
        return self.utilizador_idutilizador

class ProfessorUniversitario(models.Model):
    utilizador_idutilizador = models.OneToOneField('Utilizador', on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    unidade_organica_iduo = models.ForeignKey('UnidadeOrganica', on_delete=models.CASCADE, db_column='unidade Organica_idUO')  # Field name made lowercase. Field renamed to remove unsuitable characters.

    class Meta:
        managed = False
        db_table = 'professor universitario'

    def __str__(self):
        return self.utilizador_idutilizador

class Sessao(models.Model):
    idsessao = models.AutoField(primary_key=True)
    nrinscritos = models.IntegerField()
    vagas = models.IntegerField()
    atividade_idatividade = models.ForeignKey(Atividade, on_delete=models.CASCADE, db_column='Atividade_idAtividade')  # Field name made lowercase.
    horario_horainicio = models.ForeignKey(Horario, on_delete=models.CASCADE, db_column='Horario_horainicio')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'sessao'

    def __str__(self):
        return self.idsessao

class Tarefa(models.Model):
    idtarefa = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=45)
    concluida = models.IntegerField()
    coordenador_utilizador_idutilizador = models.ForeignKey(Coordenador, on_delete=models.CASCADE, db_column='Coordenador_Utilizador_idutilizador')  # Field name made lowercase.
    colaborador_utilizador_idutilizador = models.ForeignKey(Colaborador, on_delete=models.CASCADE, db_column='colaborador_Utilizador_idutilizador')  # Field name made lowercase.
    atividade_idatividade = models.ForeignKey(Atividade, on_delete=models.CASCADE, db_column='Atividade_idAtividade')  # Field name made lowercase.
    horario_horainicio = models.ForeignKey(Horario, on_delete=models.CASCADE, db_column='Horario_horainicio')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'tarefa'

    def __str__(self):
        return self.idtarefa

class Transporte(models.Model):
    idtransporte = models.AutoField(primary_key=True)
    capacidade = models.IntegerField()
    identificacao = models.CharField(max_length=45)
    administrador_utilizador_idutilizador1 = models.ForeignKey(Administrador, on_delete=models.CASCADE, db_column='Administrador_Utilizador_idutilizador1')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'transporte'

    def __str__(self):
        return self.idtransporte

class TransportePessoal(models.Model):
    transporte_idtransporte = models.OneToOneField(Transporte, on_delete=models.CASCADE, db_column='transporte_idtransporte', primary_key=True)

    class Meta:
        managed = False
        db_table = 'transporte pessoal'

    def __str__(self):
        return self.transporte_idtransporte

class TransporteHasHorario(models.Model):
    transporte_idtransporte = models.OneToOneField(Transporte, on_delete=models.CASCADE, db_column='transporte_idtransporte', primary_key=True)
    horario_horainicio = models.ForeignKey(Horario, on_delete=models.CASCADE, db_column='Horario_horainicio')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'transporte_has_horario'
        unique_together = (('transporte_idtransporte', 'horario_horainicio'),)

    def __str__(self):
        return self.transporte_idtransporte

class UnidadeOrganica(models.Model):
    iduo = models.IntegerField(db_column='idUO', primary_key=True)  # Field name made lowercase.
    sigla = models.CharField(max_length=5)
    campus_idcampus = models.ForeignKey(Campus, on_delete=models.CASCADE, db_column='Campus_idCampus')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'unidade organica'

    def __str__(self):
        return self.iduo

class Utilizador(models.Model):
    idutilizador = models.AutoField(primary_key=True)
    nome = models.CharField(max_length=45)
    email = models.CharField(unique=True, max_length=45, blank=True, null=True)
    telefone = models.CharField(unique=True, max_length=45, blank=True, null=True)
    password = models.CharField(max_length=45, blank=True, null=True)
    username = models.CharField(db_column='userName', max_length=45)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'utilizador'

    def __str__(self):
        return self.idutilizador

class UtilizadorHasNotificacao(models.Model):
    utilizador_idutilizador = models.OneToOneField(Utilizador, on_delete=models.CASCADE, db_column='Utilizador_idutilizador', primary_key=True)  # Field name made lowercase.
    notificacao = models.ForeignKey(Notificacao, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'utilizador_has_notificacao'
        unique_together = (('utilizador_idutilizador', 'notificacao'),)

    def __str__(self):
        return self.utilizador_idutilizador